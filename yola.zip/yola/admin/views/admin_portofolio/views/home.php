<div class="row">
  <div class="col-md-12">
    <h1>HOME.</h1>
    <h3>Welcome back, <?=$_SESSION['nama']?></h3>
  </div>
</div>