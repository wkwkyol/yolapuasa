 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portofolio</title>
    <!-- CSS Bootsrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
    <link rel="stylesheet" href="style.css">
    <!-- bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <!-- My CSS -->
    <link rel="stylesheet" href="<?=baseurl;?>/asset/css/style.css"/>
  </head>
  <body id="home">
    <!--- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-info shadow-sm fixed-top">
      <div class="container">
        <a class="navbar-brand" href="#">Holla</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" >
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#About">About</a>
            </li>
                <li class="nav-item">
                  <a class="nav-link" href="#projects">Project</a></li>
                <li class="nav-item">
                  <a class="nav-link" href="#contact">Contact</a></li>
              </ul>
            </li>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- Akhir Navbar -->
    <!--jumbotron-->
    <section class="jumbotron text-center">
      <img src="<?=baseurl;?>/asset/img/Q.jpg" alt="" width="250" height="250" class="rounded-circle img-thumbnail"./>
      <h1 class="display-4">Yola Oktaviana's here</h1>
      <p class="lead">Siswa | SMKN 4 TASIKMALAYA.</p>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffff" fill-opacity="1" d="M0,256L34.3,266.7C68.6,277,137,299,206,261.3C274.3,224,343,128,411,128C480,128,549,224,617,240C685.7,256,754,192,823,181.3C891.4,171,960,213,1029,213.3C1097.1,213,1166,171,1234,176C1302.9,181,1371,235,1406,261.3L1440,288L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"></path></svg>
   </section>
  
    <!-- About -->
    <section id="About">
      <div class="row text-center">
        <h2>About</h2>
      </div>
      <div class="row justify-content-center">
          <div class="col-md-4">
            <p>Mengikuti kebiasaan orang cina mengandalkan hokki</p>
          </div>
          <div class="col-md-4">
            <p>sssssslibawwww~</p>
          </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffff" fill-opacity="1" d="M0,192L48,170.7C96,149,192,107,288,122.7C384,139,480,213,576,234.7C672,256,768,224,864,229.3C960,235,1056,277,1152,261.3C1248,245,1344,171,1392,133.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
    </section>
    <!-- Akhir About -->
    <!-- Project -->
    <section id="project">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>W E L C O M E</h2>
          </div>
        </div>
        <div class="row justify-content-center">
         <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?=baseurl;?>/asset/img/1.jpg" class="card-img-top" alt="pic1">
          <div class="card-body">
            <p class="card-text">Sebelum sejauh matahari,Kita pernah sedekat nadi~</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?=baseurl;?>/asset/img/2.jpg" class="card-img-top" alt="pic2">
          <div class="card-body">
            <p class="card-text">Outside fashion🥵</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?=baseurl;?>/asset/img/3.webp" class="card-img-top" alt="pic2">
          <div class="card-body">
            <p class="card-text">School mode👌</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?=baseurl;?>/asset/img/4.jpg" class="card-img-top" alt="pic4">
          <div class="card-body">
            <p class="card-text">🍃Reptille Lover Fashion🍃</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?=baseurl;?>/asset/img/5.jpg" class="card-img-top" alt="pic5">
          <div class="card-body">
            <p class="card-text">🔥M Y C I R C L E🔥</p>
           </div>
           </div>
          </div>
         </div>
       </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffff" fill-opacity="1" d="M0,192L48,170.7C96,149,192,107,288,122.7C384,139,480,213,576,234.7C672,256,768,224,864,229.3C960,235,1056,277,1152,261.3C1248,245,1344,171,1392,133.3L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path></svg>
    </section>
    <!-- Akhir Project -->
    <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>Contact Me</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form>
              <div class="mb-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" id="name" aria-describedby="name">
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input type="text" class="form-control" id="email" aria-describedby="email">
                </div>
                <div class="mb-3">
                  <label for="pesan" class="form-label">Pesan</label>
                  <textarea class="form-control" id="pesan" rows="3"></textarea>
                </div>
                
             <button type="submit" class="btn btn-primary">Kirim</button>
           </form>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#58c7f3" fill-opacity="1" d="M0,192L48,170.7C96,149,192,107,288,122.7C384,139,480,213,576,234.7C672,256,768,224,864,229.3C960,235,1056,277,1152,261.3C1248,245,1344,171,1392,133.3L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
    </section>
    <!-- Akhir Contact -->
    
    <!-- Footer -->
    <footer class="text-white text-center pb-4">
      <p>Created by <a href="https:/www.instagram.com/yola_oktaa"class="text-white fw-bold">yola_oktaa</a></p>
    </footer>
    <!-- Akhir Footer -->
    <!-- JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>